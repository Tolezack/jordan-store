# Jordan Wear Frontend

Backend configurado no frontend:

```js
const API_URL = "https://jordan-store-backend.onrender.com";
```

Estrutura:

```txt
index.html
style.css
produtos.json
produtos/calca/index.html
produtos/camisa/index.html
produtos/tenis/index.html
```

Fluxo:

- A home carrega produtos do backend `/api/produtos`.
- Se o backend falhar, usa `produtos.json` local como fallback.
- Clicando numa miniatura, abre `produtos/calca/?id=...`, `produtos/camisa/?id=...` ou `produtos/tenis/?id=...`.
- A página do produto também tenta o backend primeiro e usa o `produtos.json` se precisar.

Para subir no GitHub Pages, envie todos os arquivos e pastas para o repositório do frontend.
